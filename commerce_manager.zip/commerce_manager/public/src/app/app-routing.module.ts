import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { NewProductComponent } from './new-product/new-product.component';
import { ShowProductsComponent } from './show-products/show-products.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { ShowOneProductComponent } from './show-one-product/show-one-product.component';


const routes: Routes = [
  {
    path: '',
    redirectTo:'products',
    pathMatch: 'full',
    // component: HomePageComponent
  },
  {
    path: 'products/new',
    component: NewProductComponent
  },
  {
    path: 'products',
    component: ShowProductsComponent
  },
  {
    path:'products/:id/edit',
    component: EditProductComponent
  },
    {
      path:'products/:id',
      component: ShowOneProductComponent
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
