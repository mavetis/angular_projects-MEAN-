import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-show-one-product',
  templateUrl: './show-one-product.component.html',
  styleUrls: ['./show-one-product.component.css']
})
export class ShowOneProductComponent implements OnInit {
product =[];
errors =[];
  constructor(
    private _httpService: HttpService,
    private _router: Router,
    private _route: ActivatedRoute
    ) { }

  ngOnInit() {
    this._route.params
    .subscribe((params: Params)=>{
      this._httpService.getProduct(params.id)
      .subscribe((data: any)=> {
        console.log(data);
        this.product = data.product
      });
    });
  }

  deleteProduct(id){
    this._httpService.deleteProduct(id)
    .subscribe(()=>{
      this._router.navigate(['/products']);
    })
  }
  }


